#!/bin/bash 

PATCHDIR=ics21-patches
FROMDIR=driver
TODIR=driver-patches

cd ..

cp ${FROMDIR}/pocc/options.c ${PATCHDIR}/${TODIR}/pocc/options.c 

cp ${FROMDIR}/pocc/include/pocc/options.h ${PATCHDIR}/${TODIR}/pocc/include/pocc/options.h 

cp ${FROMDIR}/pocc/driver-pastops.c ${PATCHDIR}/${TODIR}/pocc/driver-pastops.c 

cp ${FROMDIR}/pocc/driver-ponos.c ${PATCHDIR}/${TODIR}/pocc/driver-ponos.c 

cp ${FROMDIR}/src/options.c ${PATCHDIR}/${TODIR}/src/options.c 

cp ${FROMDIR}/src/options.h ${PATCHDIR}/${TODIR}/src/options.h 

cp analyzers/candl-*.tar.gz $PATCHDIR/
cp generators/punroller-*.tar.gz $PATCHDIR/
cp optimizers/ponos-*.tar.gz $PATCHDIR/
