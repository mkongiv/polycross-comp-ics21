#!/bin/bash

# General paths and options
patch_candl=1
patch_ponos=1
patch_punroller=1
patch_driver=1

PATCHDIR=ics21-patches
TAR=tar
TAROPTS="xvzf"
PREFIX="tar.gz"
BUILDCMD="bin/pocc-util make"

cp gpu-tss.py ../

cd ..

POCCROOT=`pwd`

# Patch Candl
if [ ${patch_candl} -eq 1 ]; then
  MOD=candl
  ISLH=isl-candl
  MODVER=${MOD}-0.6.6
  TRB=${MODVER}.${PREFIX}
  TRBISLH=${ISLH}.tar.gz
  CATDIR=analyzers
  cp ${PATCHDIR}/${TRB} ${CATDIR}/
  cp ${PATCHDIR}/${TRBISLH} ${CATDIR}/
  cd ${CATDIR}
  ls -l 
  if [ -f $TRB ]; then
    rm -rf $MOD
  fi
  $TAR $TAROPTS $TRB
  $TAR $TAROPTS $TRBISLH
  mv $MODVER $MOD
  cp $ISLH/*.h $MOD/source/
  ls -l
  cd $POCCROOT
  $BUILDCMD $MOD
  make install
fi

if [ ${patch_ponos} -eq 1 ]; then
  # Patch Ponos
  MOD=ponos
  MODVER=${MOD}-0.3.0
  TRB=${MODVER}.${PREFIX}
  CATDIR=optimizers
  cp ${PATCHDIR}/${TRB} ${CATDIR}/
  cd ${CATDIR}
  ls -l 
  if [ -f $TRB ]; then
    rm -rf $MOD
  fi
  $TAR $TAROPTS $TRB
  mv $MODVER $MOD
  ls -l
  cd $POCCROOT
  $BUILDCMD $MOD
  make install
fi

if [ ${patch_punroller} -eq 1 ]; then
  # Patch Ponos
  MOD=punroller
  MODVER=${MOD}-0.3.1
  TRB=${MODVER}.${PREFIX}
  CATDIR=generators
  cp ${PATCHDIR}/${TRB} ${CATDIR}/
  cd ${CATDIR}
  ls -l 
  if [ -f $TRB ]; then
    rm -rf $MOD
  fi
  $TAR $TAROPTS $TRB
  mv $MODVER $MOD
  ls -l
  cd $POCCROOT
  $BUILDCMD $MOD
  make install
fi

if [ ${patch_driver} -eq 1 ]; then
  SRCDIR=driver-patches
  TGTDIR=driver
  cp ${PATCHDIR}/${SRCDIR}/pocc/options.c ${TGTDIR}/pocc/
  cp ${PATCHDIR}/${SRCDIR}/pocc/include/pocc/options.h ${TGTDIR}/pocc/include/pocc/
  cp ${PATCHDIR}/${SRCDIR}/pocc/driver-pastops.c ${TGTDIR}/pocc/
  cp ${PATCHDIR}/${SRCDIR}/pocc/driver-ponos.c ${TGTDIR}/pocc/
  cp ${PATCHDIR}/${SRCDIR}/src/options.c ${TGTDIR}/src/
  cp ${PATCHDIR}/${SRCDIR}/src/options.h ${TGTDIR}/src/
  make install
fi
