## gpu-tss.py: this file is part of the PoCC project.
##
## PoCC, the Polyhedral Compiler Collection package
##
## Copyright (C) 2021 Louis-Noel Pouchet
##
## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public License
## as published by the Free Software Foundation; either version 2.1
## of the License, or (at your option) any later version.
##
## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## Lesser General Public License for more details.
##
## The complete GNU General Public Licence Notice can be found as the
## `COPYING.LESSER' file in the root directory.
##
## Author:
## Martin Kong <mkong@ou.edu>

import os
import sys
import re

# Need IBM Cplex. 
USECPLEX=True

def show_usage ():
  print ("Usage: {} <input> <gpu-arch:V100|RADEON7> <pbs> <balance-mode:vector-mode|reuse-mode>".format (NAME))
  print ("Example: {} gemm.c V100 2000 vector-mode".format (NAME))

def read_mld ():
  ff = open (".mld.txt", "r")
  line = ff.readline ()
  line = line.strip ()
  mld = int(line)
  ff.close ()
  return mld

def temp_rename (oldname, newname):
  cmd="mv {} {}".format (oldname, newname)
  os.system (cmd)
  return newname

def gpu_arch_valid (gpu_arch):
  if (gpu_arch.find ("V100") >= 0):
    return True
  if (gpu_arch.find ("RADEON7") >= 0):
    return True
  return False

def balance_mode_valid (balance_mode):
  if (balance_mode.find ("vector-mode") >= 0):
    return True
  if (balance_mode.find ("reuse-mode") >= 0):
    return True
  return False

def retrieve_tile_sizes (rawfile):

  try:
    ff = open (rawfile, "r")
  except FileNotFoundError:
    print ("File given not found [{}]".format (rawfile))
    sys.exit (1)

  ii = 1
  tiles = {}
  dims = {}
  maxdim = 0
  for line in ff.readlines ():
    line = line.strip ()
    depth = len(line.split (' '))
    if (depth > maxdim):
      maxdim = depth
    ii = ii + 1
    if (not line in tiles.keys()):
      tiles[line] = 1
      dims[line] = depth
    else:
      cc = tiles[line]
      tiles[line] = cc + 1
  ff.close ()


  ret = ''
  maxcard = 0
  for config, depth in dims.items():
    if (depth == maxdim):
      if (tiles[config] > maxcard):
        maxcard = tiles[config]
        ret = config

  return ret

NAME="gpu-tss.py"
if (len(sys.argv) != 5):
  show_usage ()
  sys.exit (1)

infile = sys.argv[1]
gpu_arch = sys.argv[2]
pbs = int(sys.argv[3])
balance_mode = sys.argv[4]

print ("Input file given  : {}".format (infile))
print ("GPU Arch given    : {}".format (gpu_arch))
print ("Problem size given: {}".format (pbs))
print ("Balance mode given: {}".format (balance_mode))

if (not gpu_arch_valid (gpu_arch)):
  print ("Invalid GPU arch given. Valid ones are 'V100' and 'RADEON7'")
  show_usage ()
  sys.exit (1)

if (not balance_mode_valid (balance_mode)):
  print ("Invalid tile size selection balance mode given. Valid ones are 'reuse-mode' and 'vector-mode'.")
  show_usage ()
  sys.exit (1)


TEMP="dummy"
cmd="cp {} {}.c".format (infile, TEMP)
os.system (cmd)

compiler="bin/pocc"
options=" --tpt-pretile --default-ctxt "
cmd="{} {} {}.c  2>&1 > /dev/null ".format (compiler, options, TEMP)
os.system (cmd)
os.system ("mv {}.pocc.c {}-tpt.c".format (TEMP, TEMP))

# Compute dependence gist.
SCHED_DEPTH = read_mld () * 2 + 1
args=""
args+=" --ponos "
if (USECPLEX):
  args+=" --ponos-solver cplex "
else:
  args+=" --ponos-pip-gmp "

args+=" --dependence-gist "
args+=" --ponos-solver-pre "
args+=" --ponos-farkas-max "
args+=" --ponos-farkas-nored "

args+=" --ponos-coef-N "
args+=" --ponos-build-2dp1 "
args+=" --ponos-obj codelet "
args+=" --ponos-sched-sz {} ".format (SCHED_DEPTH)
args+=" --default-ctxt "
args+=" --ponos-chunked-arch {}".format (gpu_arch)

args+=" --ponos-chunked "
args+=" --ponos-coef 30 "
args+=" --ponos-K 40 "

cmd="{} {} {}.c  2>&1 > /dev/null ".format (compiler, args, TEMP)
os.system (cmd)

# Call tile size selection options.
SCHED_DEPTH = read_mld () * 4 + 1
args=""
args+=" --quiet "
args+=" --ponos "
if (USECPLEX):
  args+=" --ponos-solver cplex "
else:
  args+=" --ponos-pip-gmp "

args+=" --ponos-coef-N "
args+=" --ponos-build-2dp1 "
args+=" --ponos-sched-sz  {} ".format (SCHED_DEPTH)
args+=" --user-ctxt 1"
args+=" --past-hoist-lb "
args+=" --ponos-chunked-arch {} ".format (gpu_arch)

args+=" --ponos-chunked "
args+=" --ponos-tpt-agpu "
args+=" --ponos-tpt-tile "

args+=" --ponos-tpt-N {} ".format (pbs)
args+=" --ponos-tpt-balance-mode {} ".format (balance_mode)

args+=" --ponos-coef 20 "
args+=" --ponos-K 40 "

cmd="{} {} {}-tpt.c 2>&1 > {}.log".format (compiler, args, TEMP, TEMP)
os.system (cmd)

# Extract tile sizes from output.
bm = re.sub (".c","", infile)
tiledfile="{}.atss.{}.c".format (bm, gpu_arch)
os.system ("mv {}-tpt.pocc.c {}".format (TEMP, tiledfile))
alltiles="{}.tiles.all".format (bm)
tsfile="{}.tiles".format (bm)
cmd="grep -e 'Tile sizes collected for statement ' {}.log | sed -e 's/^.*: //g' > {}".format (TEMP, alltiles)
os.system (cmd)
tilelist = retrieve_tile_sizes (alltiles)
print ("Tile Sizes: {}".format (tilelist))

os.system ("rm -f {}*".format (TEMP))
